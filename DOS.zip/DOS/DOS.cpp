
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string.h>

using namespace std;

void input(char ip[]){
	
	cout << "Write the IP: " << endl;
	cin >> ip;
	
}

void defineFreq(int *freq){
	
	cout << "Write the frequency: " << endl;
	cin >> *freq;
	
}

int main(){
	
	char ip[16];
	int freq, i;
	char final[50];
	
	input(ip);
	defineFreq(&freq);
	
	strcpy(final, "ping ");
	
	strcat(final, ip);
	strcat(final, " -t -l 65500");
	
	cout << final << endl;
	
	for(i=0; i<freq; i++){
		
		system(final);
		
	}
	
	return 0;
}
